import sys
import logging
import rds_config
import pymysql

import json
import dateutil.parser
import datetime
import time
import os
import math
import random


#rds settings
rds_host  = "goatsfinedb.cy05yahye4yx.us-east-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name


logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handler(event, context):
    """
    This function fetches content from mysql RDS instance
    """

    item_count = 0

    with conn.cursor() as cur:
        cur.execute("create table Employee4 ( EmpID  int NOT NULL, Name varchar(255) NOT NULL, PRIMARY KEY (EmpID))")  
        cur.execute('insert into Employee4 (EmpID, Name) values(1, "Joe")')
        cur.execute('insert into Employee4 (EmpID, Name) values(2, "Bob")')
        cur.execute('insert into Employee4 (EmpID, Name) values(4, "wiley")')
        conn.commit()
        cur.execute("select * from Employee3")
        for row in cur:
            item_count += 1
            logger.info(row)
            #print(row)
    

    return "Added %d items from RDS MySQL table" %(item_count)


""" --- Creates MySQL Connection --- """

def openConnection():
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=3)
        logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()    


""" --- Functions that control the bot's behavior --- """

def register_fines(intent_request):
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=3)
        logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()
    item_count = 0
    userid = intent_request['userId'].split(":")[2]
    logger.info('insert into tblFines (userid, fineamount) values('+userid+', 1.00)')
    with conn.cursor() as cur:
        cur.execute('insert into tblFines (userid, fineamount) values("'+userid+'", 1.00)')
        conn.commit()
        cur.execute("select * from tblFines where userid='"+userid+"'")
    for row in cur:
        item_count += 1
        logger.info(row)
        #print(row)
    return {"sessionAttributes":{
    
    },
  "dialogAction": {
    "type": "Close",
    "fulfillmentState": "Fulfilled",
    "message": {
      "contentType": "PlainText",
      "content": "Hi, <@username>" + userid + ">. You have been fined! \nYou have " + str(item_count) + " fines."
        }
    }
}

""" --- Intents --- """

def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """

    logger.debug('dispatch userId={}, intentName={}'.format(intent_request['userId'], intent_request['currentIntent']['name']))

    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'Fines':
        return register_fines(intent_request)
    raise Exception('Intent with name ' + intent_name + ' not supported')
    

""" --- Main handler --- """

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # By default, treat the user request as coming from the America/New_York time zone.
    os.environ['TZ'] = 'America/New_York'
    time.tzset()
    logger.debug('event.bot.name={}'.format(event['bot']['name']))
    return dispatch(event)