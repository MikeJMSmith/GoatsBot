#config file containing credentials for rds mysql instance
db_username = "mysqladmin"
db_password = "d3f1anc3"
db_name = "GoatsFineDB"